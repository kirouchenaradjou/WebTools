package excercise2_stack;

public enum Suit {  
	C, D, H, S 
	}


